package excecao;

public class ObjetoNaoEncontradoException extends Exception {
    private final static long serialVersionUID = 1;

    public ObjetoNaoEncontradoException() {
    }
}