package excecao;

public class PermissaoNegadaException extends RuntimeException {
	private final static long serialVersionUID = 1;

    public PermissaoNegadaException() {
	super();
    }
}
